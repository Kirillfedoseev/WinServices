Instruction for launch
1) launch Server.exe 
	a) without arguments 
	b) with --service argument
2) Launch Client.exe 
3) Type any anything and it will be executed on remote cmd

The example of work can be found in Screenshot.png