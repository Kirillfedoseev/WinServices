This is implementation of performance library for Task 2

The basic functionality is about counting the overall amount of received bytes.
It is very simple example, but it works and can be extended with some changes.

On the screenshot you can find the results and example of working system.

For launch this you should:
1) Install the performance library (highly recommend to rebuild it on own PC)
2) Add indicator "Signal generator/constant value" in perfmon 
3) Launch system from task 2 

See on results it should increase the value after server has been received the bytes.
