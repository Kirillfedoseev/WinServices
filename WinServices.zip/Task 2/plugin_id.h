 #include <initguid.h>

DEFINE_GUID(plugin1_id, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
DEFINE_GUID(plugin2_id, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0);